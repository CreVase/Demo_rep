package a;

/* loaded from: classes.dex */
public final class du {
    static {
        synchronized (bx.f3b) {
            if (!bx.f2a) {
                System.loadLibrary("pnfwifbfud");
                bx.f2a = true;
            }
        }
    }

    public static native void d(int i, bx bxVar);

    /* JADX WARN: Code restructure failed: missing block: B:288:0x02c7, code lost:            if (defpackage.tf3.W("/system/xbin/su") != false) goto L210;     */
    @androidx.annotation.Keep
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void u(int r6, a.bx r7) {
        /*
            Method dump skipped, instructions count: 1980
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a.du.u(int, a.bx):void");
    }
}
