package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import defpackage.wj3;

/* loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(wj3 wj3Var) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(wj3Var);
    }

    public static void write(IconCompat iconCompat, wj3 wj3Var) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, wj3Var);
    }
}
