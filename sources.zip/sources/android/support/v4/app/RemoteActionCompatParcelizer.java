package android.support.v4.app;

import androidx.core.app.RemoteActionCompat;
import defpackage.wj3;

/* loaded from: classes.dex */
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(wj3 wj3Var) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(wj3Var);
    }

    public static void write(RemoteActionCompat remoteActionCompat, wj3 wj3Var) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, wj3Var);
    }
}
