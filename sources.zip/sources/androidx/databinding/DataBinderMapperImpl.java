package androidx.databinding;

/* loaded from: classes.dex */
public class DataBinderMapperImpl extends MergedDataBinderMapper {
    public DataBinderMapperImpl() {
        c(new com.security.xvpn.z35kb.DataBinderMapperImpl());
    }
}
