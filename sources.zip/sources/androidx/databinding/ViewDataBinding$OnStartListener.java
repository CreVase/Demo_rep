package androidx.databinding;

import defpackage.ak1;
import defpackage.tj1;
import defpackage.w22;

/* loaded from: classes.dex */
class ViewDataBinding$OnStartListener implements ak1 {
    @w22(tj1.ON_START)
    public void onStart() {
        throw null;
    }
}
