package androidx.fragment.app;

import defpackage.bk1;
import defpackage.tj1;
import defpackage.zj1;

/* loaded from: classes.dex */
class FragmentManager$6 implements zj1 {
    @Override // defpackage.zj1
    public final void e(bk1 bk1Var, tj1 tj1Var) {
        if (tj1Var != tj1.ON_START) {
            if (tj1Var != tj1.ON_DESTROY) {
                return;
            } else {
                throw null;
            }
        }
        throw null;
    }
}
