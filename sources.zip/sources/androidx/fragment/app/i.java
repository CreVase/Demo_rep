package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public boolean f228a;

    /* renamed from: b, reason: collision with root package name */
    public int f229b;
    public int c;
    public int d;
    public int e;
    public int f;
    public ArrayList g;
    public ArrayList h;
    public Object i = null;
    public Object j;
    public Object k;
    public Object l;
    public Object m;
    public Object n;
    public Boolean o;
    public Boolean p;
    public float q;
    public View r;
    public boolean s;

    public i() {
        Object obj = Fragment.USE_DEFAULT_TRANSITION;
        this.j = obj;
        this.k = null;
        this.l = obj;
        this.m = null;
        this.n = obj;
        this.q = 1.0f;
        this.r = null;
    }
}
