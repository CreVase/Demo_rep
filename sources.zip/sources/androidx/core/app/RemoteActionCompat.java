package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import defpackage.yj3;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements yj3 {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f190a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f191b;
    public CharSequence c;
    public PendingIntent d;
    public boolean e;
    public boolean f;
}
