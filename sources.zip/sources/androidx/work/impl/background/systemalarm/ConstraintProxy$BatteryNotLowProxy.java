package androidx.work.impl.background.systemalarm;

import defpackage.i70;

/* loaded from: classes.dex */
public class ConstraintProxy$BatteryNotLowProxy extends i70 {
}
