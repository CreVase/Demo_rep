package androidx.work.impl.background.systemalarm;

import defpackage.i70;

/* loaded from: classes.dex */
public class ConstraintProxy$NetworkStateProxy extends i70 {
}
