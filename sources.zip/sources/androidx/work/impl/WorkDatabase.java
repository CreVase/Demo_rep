package androidx.work.impl;

import defpackage.eb3;
import defpackage.gl2;
import defpackage.ok0;
import defpackage.ts3;
import defpackage.y33;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public abstract class WorkDatabase extends gl2 {
    public static final long j = TimeUnit.DAYS.toMillis(1);
    public static final /* synthetic */ int k = 0;

    public abstract ok0 i();

    public abstract ok0 j();

    public abstract y33 k();

    public abstract ok0 l();

    public abstract eb3 m();

    public abstract ts3 n();

    public abstract ok0 o();
}
