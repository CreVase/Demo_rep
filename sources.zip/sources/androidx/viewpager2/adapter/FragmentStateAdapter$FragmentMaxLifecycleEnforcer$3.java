package androidx.viewpager2.adapter;

import defpackage.bk1;
import defpackage.tj1;
import defpackage.zj1;

/* loaded from: classes.dex */
class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements zj1 {
    @Override // defpackage.zj1
    public final void e(bk1 bk1Var, tj1 tj1Var) {
        throw null;
    }
}
