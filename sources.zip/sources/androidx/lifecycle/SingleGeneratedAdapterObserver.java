package androidx.lifecycle;

import defpackage.bk1;
import defpackage.tj1;
import defpackage.zj1;

/* loaded from: classes.dex */
public final class SingleGeneratedAdapterObserver implements zj1 {
    @Override // defpackage.zj1
    public final void e(bk1 bk1Var, tj1 tj1Var) {
        throw null;
    }
}
