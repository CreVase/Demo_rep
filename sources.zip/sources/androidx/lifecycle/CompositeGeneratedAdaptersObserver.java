package androidx.lifecycle;

import defpackage.bk1;
import defpackage.e51;
import defpackage.tj1;
import defpackage.zj1;
import java.util.HashMap;

/* loaded from: classes.dex */
public final class CompositeGeneratedAdaptersObserver implements zj1 {

    /* renamed from: a, reason: collision with root package name */
    public final e51[] f247a;

    public CompositeGeneratedAdaptersObserver(e51[] e51VarArr) {
        this.f247a = e51VarArr;
    }

    @Override // defpackage.zj1
    public final void e(bk1 bk1Var, tj1 tj1Var) {
        new HashMap();
        e51[] e51VarArr = this.f247a;
        if (e51VarArr.length <= 0) {
            if (e51VarArr.length <= 0) {
                return;
            }
            e51 e51Var = e51VarArr[0];
            throw null;
        }
        e51 e51Var2 = e51VarArr[0];
        throw null;
    }
}
