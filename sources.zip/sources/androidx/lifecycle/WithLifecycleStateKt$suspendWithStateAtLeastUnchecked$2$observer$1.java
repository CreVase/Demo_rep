package androidx.lifecycle;

import defpackage.bk1;
import defpackage.rj1;
import defpackage.tj1;
import defpackage.zj1;

/* loaded from: classes.dex */
public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1 implements zj1 {
    @Override // defpackage.zj1
    public final void e(bk1 bk1Var, tj1 tj1Var) {
        tj1.Companion.getClass();
        rj1.b(null);
        throw null;
    }
}
