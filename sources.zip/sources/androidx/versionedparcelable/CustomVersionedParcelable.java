package androidx.versionedparcelable;

import defpackage.yj3;

/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements yj3 {
}
