package com.bumptech.glide.load.data;

import android.os.ParcelFileDescriptor;
import java.io.IOException;

/* loaded from: classes.dex */
final class ParcelFileDescriptorRewinder$InternalRewinder {
    public ParcelFileDescriptor rewind() throws IOException {
        throw null;
    }
}
