package com.bumptech.glide;

import android.content.Context;
import com.security.xvpn.z35kb.GlideAppModule;

/* loaded from: classes.dex */
final class GeneratedAppGlideModuleImpl extends GeneratedAppGlideModule {
    public GeneratedAppGlideModuleImpl(Context context) {
        new GlideAppModule();
    }
}
