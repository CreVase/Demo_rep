package com.bumptech.glide;

import defpackage.tf3;

/* loaded from: classes.dex */
abstract class GeneratedAppGlideModule extends tf3 {
    public GeneratedAppGlideModule() {
        super(0);
    }
}
