package com.bumptech.glide.manager;

import defpackage.ak1;
import defpackage.bk1;
import defpackage.tj1;
import defpackage.w22;
import defpackage.xi3;

/* loaded from: classes.dex */
final class LifecycleLifecycle implements ak1 {
    @w22(tj1.ON_DESTROY)
    public void onDestroy(bk1 bk1Var) {
        int i = xi3.f5165a;
        throw null;
    }

    @w22(tj1.ON_START)
    public void onStart(bk1 bk1Var) {
        int i = xi3.f5165a;
        throw null;
    }

    @w22(tj1.ON_STOP)
    public void onStop(bk1 bk1Var) {
        int i = xi3.f5165a;
        throw null;
    }
}
