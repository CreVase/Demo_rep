package com.android.installreferrer.commons;

/* loaded from: classes.dex */
public final class InstallReferrerCommons {
    public static void logVerbose(String str, String str2) {
    }

    public static void logWarn(String str, String str2) {
    }
}
