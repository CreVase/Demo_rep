package com.android.installreferrer.api;

/* loaded from: classes.dex */
public interface InstallReferrerStateListener {
    void onInstallReferrerServiceDisconnected();

    void onInstallReferrerSetupFinished(int i);
}
