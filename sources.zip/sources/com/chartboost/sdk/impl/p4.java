package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public class p4 {

    /* renamed from: a, reason: collision with root package name */
    public static p4 f1067a = new p4();

    public <T> T a(T t) {
        return t;
    }

    public static p4 a() {
        return f1067a;
    }
}
