package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public class dc {

    /* renamed from: a, reason: collision with root package name */
    public final fb f777a;

    /* renamed from: b, reason: collision with root package name */
    public final String f778b;
    public final t4 c;
    public final String d;

    public String a() {
        return this.d;
    }

    public t4 b() {
        return this.c;
    }

    public fb c() {
        return this.f777a;
    }

    public String d() {
        return this.f778b;
    }
}
