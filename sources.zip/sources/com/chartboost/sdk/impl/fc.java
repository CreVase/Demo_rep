package com.chartboost.sdk.impl;

import android.content.Context;
import android.os.Handler;

/* loaded from: classes.dex */
public class fc {
    public bc a(Handler handler, Context context, ya yaVar, qb qbVar) {
        return new bc(handler, context, yaVar, qbVar);
    }
}
