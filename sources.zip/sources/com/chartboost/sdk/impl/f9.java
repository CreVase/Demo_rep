package com.chartboost.sdk.impl;

import android.content.Context;
import java.util.List;

/* loaded from: classes.dex */
public interface f9 {
    String A();

    String B();

    void C();

    void a(float f);

    void a(float f, float f2);

    void a(Context context, Boolean bool);

    void a(Context context, String str, Boolean bool);

    void a(m7 m7Var);

    void a(w9 w9Var);

    void a(List<x9> list);

    void a(boolean z, String str);

    void b(float f);

    void c(String str);

    void d(String str);

    void e(String str);

    String f();

    void g();

    String h();

    void i();

    void j();

    void m();

    void p();

    String r();

    void s();

    void t();

    void u();

    String v();

    void y();

    void z();
}
