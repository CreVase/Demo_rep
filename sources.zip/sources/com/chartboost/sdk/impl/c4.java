package com.chartboost.sdk.impl;

import android.content.Context;
import com.chartboost.sdk.impl.pa;
import defpackage.qm0;
import defpackage.yd0;

/* loaded from: classes.dex */
public interface c4 {
    void a();

    void a(Context context);

    void a(pa.a aVar);

    void a(r3 r3Var);

    void a(y9 y9Var);

    void a(y9 y9Var, r3 r3Var);

    boolean a(String str);

    s3 b(String str);

    yd0 b();

    qm0 c();

    float d(String str);
}
