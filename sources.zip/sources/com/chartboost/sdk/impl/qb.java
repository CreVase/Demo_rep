package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface qb {
    void a(float f);
}
