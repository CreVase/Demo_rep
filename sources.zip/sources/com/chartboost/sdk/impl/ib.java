package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public class ib {
    public ya a() {
        return new ya();
    }
}
