package com.chartboost.sdk.impl;

import defpackage.ng0;

/* loaded from: classes.dex */
public enum r3 {
    NONE(0),
    STOPPED_QUEUE(1),
    MAX_COUNT_TIME_WINDOW(2),
    FORCED_OUT(3);


    /* renamed from: b, reason: collision with root package name */
    public static final a f1103b = new a(null);

    /* renamed from: a, reason: collision with root package name */
    public final int f1104a;

    /* loaded from: classes.dex */
    public static final class a {
        public /* synthetic */ a(ng0 ng0Var) {
            this();
        }

        public a() {
        }
    }

    r3(int i) {
        this.f1104a = i;
    }

    public final int b() {
        return this.f1104a;
    }
}
