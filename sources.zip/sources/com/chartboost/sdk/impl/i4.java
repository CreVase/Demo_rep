package com.chartboost.sdk.impl;

import java.io.File;

/* loaded from: classes.dex */
public interface i4 {
    File a();

    File a(String str);

    File b();

    File c();
}
