package com.chartboost.sdk.impl;

import android.annotation.SuppressLint;
import javax.net.ssl.X509TrustManager;

/* loaded from: classes.dex */
public final class p8 {

    /* renamed from: b, reason: collision with root package name */
    public static boolean f1075b;
    public static final String d = null;
    public static final X509TrustManager e = null;

    /* renamed from: a, reason: collision with root package name */
    public static final p8 f1074a = new p8();
    public static final String c = "";

    public static final void a(String str) {
    }

    public static final void b(String str) {
    }

    public static final void c(String str) {
    }

    public final boolean d() {
        return f1075b;
    }

    public static final String a() {
        return d;
    }

    public static final String b() {
        return c;
    }

    @SuppressLint({"CustomX509TrustManager"})
    public static final X509TrustManager c() {
        return e;
    }
}
