package com.chartboost.sdk.impl;

import android.annotation.SuppressLint;
import android.content.Context;

@SuppressLint({"ViewConstructor"})
/* loaded from: classes.dex */
public final class ua extends y2 {
    public ua(Context context, String str, l3 l3Var, f9 f9Var, s9 s9Var, String str2) {
        super(context, str, l3Var, f9Var, s9Var, str2);
        addView(this.d);
        l3Var.a();
        l3Var.d();
    }
}
