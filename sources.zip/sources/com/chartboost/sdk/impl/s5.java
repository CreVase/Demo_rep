package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum s5 {
    LOADING(0),
    LOADED(1),
    DISPLAYED(2),
    CACHED(3),
    DISMISSING(4),
    NONE(5);


    /* renamed from: a, reason: collision with root package name */
    public final int f1128a;

    s5(int i) {
        this.f1128a = i;
    }
}
