package com.chartboost.sdk.impl;

import org.json.JSONObject;

/* loaded from: classes.dex */
public interface e3 {
    void a(String str);

    void a(JSONObject jSONObject);
}
