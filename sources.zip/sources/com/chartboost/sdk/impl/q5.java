package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;

/* loaded from: classes.dex */
public interface q5 {
    void D();

    void a();

    void a(s5 s5Var);

    void a(String str, CBError.CBClickError cBClickError);

    void a(boolean z);

    void b();

    void b(boolean z);

    void c();

    void l();
}
