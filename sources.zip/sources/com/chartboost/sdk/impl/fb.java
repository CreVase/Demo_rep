package com.chartboost.sdk.impl;

import android.view.View;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class fb extends WeakReference<View> {
    public fb(View view) {
        super(view);
    }
}
