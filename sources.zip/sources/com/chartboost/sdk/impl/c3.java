package com.chartboost.sdk.impl;

import org.json.JSONObject;

/* loaded from: classes.dex */
public interface c3 {
    void a(String str);

    void a(JSONObject jSONObject);
}
