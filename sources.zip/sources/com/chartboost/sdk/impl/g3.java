package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum g3 {
    CONNECTION_UNKNOWN(-1),
    CONNECTION_ERROR(0),
    CONNECTION_WIFI(1),
    CONNECTION_MOBILE(2);


    /* renamed from: a, reason: collision with root package name */
    public final int f839a;

    g3(int i) {
        this.f839a = i;
    }

    public final int b() {
        return this.f839a;
    }
}
