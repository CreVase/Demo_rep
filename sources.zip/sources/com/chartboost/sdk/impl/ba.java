package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class ba {

    /* renamed from: a, reason: collision with root package name */
    public static final String f732a = "aa";

    /* JADX WARN: Removed duplicated region for block: B:11:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0025 A[Catch: Exception -> 0x0010, TryCatch #0 {Exception -> 0x0010, blocks: (B:21:0x0003, B:5:0x0015, B:9:0x0020, B:15:0x0025, B:17:0x0033), top: B:20:0x0003 }] */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0020 A[Catch: Exception -> 0x0010, TryCatch #0 {Exception -> 0x0010, blocks: (B:21:0x0003, B:5:0x0015, B:9:0x0020, B:15:0x0025, B:17:0x0033), top: B:20:0x0003 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final com.chartboost.sdk.impl.y7 b(com.chartboost.sdk.impl.y9 r3, com.chartboost.sdk.impl.d9 r4, com.chartboost.sdk.impl.r4 r5) {
        /*
            r0 = 0
            if (r5 == 0) goto L12
            java.io.File r1 = r5.c()     // Catch: java.lang.Exception -> L10
            java.lang.String r2 = r3.d()     // Catch: java.lang.Exception -> L10
            java.io.File r5 = r5.a(r1, r2)     // Catch: java.lang.Exception -> L10
            goto L13
        L10:
            r3 = move-exception
            goto L38
        L12:
            r5 = r0
        L13:
            if (r5 == 0) goto L1d
            boolean r1 = r5.exists()     // Catch: java.lang.Exception -> L10
            r2 = 1
            if (r1 != r2) goto L1d
            goto L1e
        L1d:
            r2 = 0
        L1e:
            if (r2 == 0) goto L25
            java.io.RandomAccessFile r3 = r4.a(r5)     // Catch: java.lang.Exception -> L10
            goto L42
        L25:
            java.io.File r5 = r3.b()     // Catch: java.lang.Exception -> L10
            java.lang.String r3 = r3.d()     // Catch: java.lang.Exception -> L10
            java.io.File r3 = r4.a(r5, r3)     // Catch: java.lang.Exception -> L10
            if (r3 == 0) goto L41
            java.io.RandomAccessFile r3 = r4.a(r3)     // Catch: java.lang.Exception -> L10
            goto L42
        L38:
            java.lang.String r4 = com.chartboost.sdk.impl.ba.f732a
            java.lang.String r3 = r3.toString()
            com.chartboost.sdk.impl.f6.b(r4, r3)
        L41:
            r3 = r0
        L42:
            if (r3 == 0) goto L49
            com.chartboost.sdk.impl.y7 r0 = new com.chartboost.sdk.impl.y7
            r0.<init>(r3)
        L49:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.chartboost.sdk.impl.ba.b(com.chartboost.sdk.impl.y9, com.chartboost.sdk.impl.d9, com.chartboost.sdk.impl.r4):com.chartboost.sdk.impl.y7");
    }
}
