package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface s6 {
    w6 a();

    t6 b();
}
