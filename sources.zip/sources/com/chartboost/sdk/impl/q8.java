package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface q8 {
    void a(int i, int i2);
}
