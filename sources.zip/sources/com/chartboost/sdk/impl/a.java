package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface a {
    void a();

    void a(ra raVar);
}
