package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface k9 {
    y3 a();
}
