package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class u2 {

    /* renamed from: a, reason: collision with root package name */
    public final String f1170a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1171b;
    public final String c;
    public final String d;
    public final String e;
    public final Float f;
    public final Float g;
    public final r5 h;
    public final Boolean i;

    public u2(String str, String str2, String str3, String str4, String str5, Float f, Float f2, r5 r5Var, Boolean bool) {
        this.f1170a = str;
        this.f1171b = str2;
        this.c = str3;
        this.d = str4;
        this.e = str5;
        this.f = f;
        this.g = f2;
        this.h = r5Var;
        this.i = bool;
    }

    public final String a() {
        return this.f1171b;
    }

    public final String b() {
        return this.d;
    }

    public final String c() {
        return this.e;
    }

    public final r5 d() {
        return this.h;
    }

    public final String e() {
        return this.f1170a;
    }

    public final Boolean f() {
        return this.i;
    }

    public final String g() {
        return this.c;
    }

    public final Float h() {
        return this.g;
    }

    public final Float i() {
        return this.f;
    }
}
