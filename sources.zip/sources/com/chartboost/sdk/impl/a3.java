package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class a3 {

    /* renamed from: a, reason: collision with root package name */
    public final String f698a;

    /* renamed from: b, reason: collision with root package name */
    public final String f699b;
    public final String c;
    public final int d;
    public final String e;
    public final Float f;
    public final Float g;

    public a3(String str, String str2, String str3, int i, String str4, Float f, Float f2) {
        this.f698a = str;
        this.f699b = str2;
        this.c = str3;
        this.d = i;
        this.e = str4;
        this.f = f;
        this.g = f2;
    }

    public final String a() {
        return this.f699b;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.f698a;
    }

    public final int d() {
        return this.d;
    }

    public final String e() {
        return this.e;
    }

    public final Float f() {
        return this.g;
    }

    public final Float g() {
        return this.f;
    }
}
