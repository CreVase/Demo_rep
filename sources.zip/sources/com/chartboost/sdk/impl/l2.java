package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public class l2 {

    /* renamed from: a, reason: collision with root package name */
    public final String f957a;

    /* renamed from: b, reason: collision with root package name */
    public final String f958b;
    public final String c;
    public final String d;
    public final String e;
    public final int f;

    public l2(String str, String str2, String str3, String str4, String str5, int i) {
        this.f957a = str;
        this.f958b = str2;
        this.c = str3;
        this.d = str4;
        this.e = str5;
        this.f = i;
    }

    public String a() {
        return this.f958b;
    }

    public String b() {
        return this.c;
    }

    public String c() {
        return this.e;
    }

    public String d() {
        return this.d;
    }

    public int e() {
        return this.f;
    }
}
