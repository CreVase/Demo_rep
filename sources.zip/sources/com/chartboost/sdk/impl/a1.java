package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum a1 {
    FAILURE,
    READY_TO_SHOW,
    SUCCESS
}
