package com.chartboost.sdk.impl;

import com.chartboost.sdk.impl.nb;

/* loaded from: classes.dex */
public class ac extends nb {
    public ac(nb.b bVar) {
        super(bVar);
    }

    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public String doInBackground(Object... objArr) {
        this.f1023b.a(null);
        return null;
    }
}
