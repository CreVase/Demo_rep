package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface l0 {
    void a();

    void a(long j);

    void a(String str);

    void b();

    void b(long j);

    void c();

    void d();
}
