package com.chartboost.sdk.impl;

import android.content.Context;
import com.chartboost.sdk.impl.pa;
import defpackage.qm0;
import defpackage.yd0;

/* loaded from: classes.dex */
public final class g4 implements c4 {

    /* renamed from: b, reason: collision with root package name */
    public static final g4 f840b = new g4();

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e4 f841a = new e4(null, 1, null);

    @Override // com.chartboost.sdk.impl.c4
    public void a() {
        this.f841a.a();
    }

    @Override // com.chartboost.sdk.impl.c4
    public yd0 b() {
        return this.f841a.b();
    }

    @Override // com.chartboost.sdk.impl.c4
    public qm0 c() {
        return this.f841a.c();
    }

    @Override // com.chartboost.sdk.impl.c4
    public float d(String str) {
        return this.f841a.d(str);
    }

    @Override // com.chartboost.sdk.impl.c4
    public void a(Context context) {
        this.f841a.a(context);
    }

    @Override // com.chartboost.sdk.impl.c4
    public s3 b(String str) {
        return this.f841a.b(str);
    }

    @Override // com.chartboost.sdk.impl.c4
    public void a(pa.a aVar) {
        this.f841a.a(aVar);
    }

    @Override // com.chartboost.sdk.impl.c4
    public void a(r3 r3Var) {
        this.f841a.a(r3Var);
    }

    @Override // com.chartboost.sdk.impl.c4
    public void a(y9 y9Var) {
        this.f841a.a(y9Var);
    }

    @Override // com.chartboost.sdk.impl.c4
    public void a(y9 y9Var, r3 r3Var) {
        this.f841a.a(y9Var, r3Var);
    }

    @Override // com.chartboost.sdk.impl.c4
    public boolean a(String str) {
        return this.f841a.a(str);
    }
}
