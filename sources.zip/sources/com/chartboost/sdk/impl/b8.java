package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface b8 {
    d8 a();
}
