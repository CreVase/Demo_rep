package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class gb {

    /* renamed from: a, reason: collision with root package name */
    public static final Boolean f846a = Boolean.FALSE;
}
