package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum q9 {
    TRACKING_UNKNOWN(-1),
    TRACKING_ENABLED(0),
    TRACKING_LIMITED(1);


    /* renamed from: a, reason: collision with root package name */
    public final int f1088a;

    q9(int i) {
        this.f1088a = i;
    }

    public final int b() {
        return this.f1088a;
    }
}
