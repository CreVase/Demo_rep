package com.chartboost.sdk.impl;

import android.content.Context;

/* loaded from: classes.dex */
public final class r6 {

    /* renamed from: a, reason: collision with root package name */
    public static pb f1109a = new pb();

    public static void a(Context context) {
        f1109a.a(context.getApplicationContext());
    }

    public static void b() {
        f1109a.b();
    }

    public static boolean a() {
        return f1109a.a();
    }
}
