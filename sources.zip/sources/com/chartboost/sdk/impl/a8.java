package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public class a8 {

    /* renamed from: a, reason: collision with root package name */
    public final t7 f704a;

    public a8(t7 t7Var) {
        this.f704a = t7Var;
    }

    public void a(String str) {
        this.f704a.a(str);
    }
}
