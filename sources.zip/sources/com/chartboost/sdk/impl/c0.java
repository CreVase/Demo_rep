package com.chartboost.sdk.impl;

import android.content.Context;
import com.chartboost.sdk.internal.Model.CBError;

/* loaded from: classes.dex */
public interface c0 {
    void a(Context context);

    void a(s0 s0Var);

    void a(s0 s0Var, CBError.CBImpressionError cBImpressionError);

    void a(String str);

    void a(String str, int i);

    void a(String str, String str2, CBError.CBClickError cBClickError);

    void b(s0 s0Var);

    void b(String str);

    void k();

    void n();
}
