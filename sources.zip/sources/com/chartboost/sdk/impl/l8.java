package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class l8 {

    /* renamed from: a, reason: collision with root package name */
    public static final String f965a = "k8";
}
