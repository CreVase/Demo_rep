package com.chartboost.sdk.impl;

import com.chartboost.sdk.Mediation;

/* loaded from: classes.dex */
public final class b9 {

    /* renamed from: a, reason: collision with root package name */
    public final String f730a;

    /* renamed from: b, reason: collision with root package name */
    public final String f731b;
    public final int c;
    public final String d;
    public final Mediation e;

    public b9(String str, String str2, int i, String str3, Mediation mediation) {
        this.f730a = str;
        this.f731b = str2;
        this.c = i;
        this.d = str3;
        this.e = mediation;
    }

    public final String a() {
        return this.f730a;
    }

    public final String b() {
        return this.d;
    }

    public final String c() {
        return this.f731b;
    }

    public final Mediation d() {
        return this.e;
    }

    public final int e() {
        return this.c;
    }
}
