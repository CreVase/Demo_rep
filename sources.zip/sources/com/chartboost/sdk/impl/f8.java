package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class f8 {

    /* renamed from: a, reason: collision with root package name */
    public static final String f823a = "e8";
}
