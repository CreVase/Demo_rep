package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;
import com.chartboost.sdk.view.CBImpressionActivity;

/* loaded from: classes.dex */
public interface a0 {
    void a(CBError.CBImpressionError cBImpressionError);

    void a(CBImpressionActivity cBImpressionActivity);

    void d();

    boolean e();

    void o();

    void q();

    void w();

    void x();
}
