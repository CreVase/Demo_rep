package com.chartboost.sdk.impl;

import android.content.Context;

/* loaded from: classes.dex */
public final class s2 {

    /* renamed from: b, reason: collision with root package name */
    public static final s2 f1122b = new s2();

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ m3 f1123a = new m3();

    public q0 a() {
        return this.f1123a.a();
    }

    public String b() {
        return this.f1123a.b();
    }

    public String c() {
        return this.f1123a.c();
    }

    public t0 d() {
        return this.f1123a.e();
    }

    public a4 e() {
        return this.f1123a.f();
    }

    public boolean f() {
        return this.f1123a.g();
    }

    public s6 g() {
        return this.f1123a.h();
    }

    public r7 h() {
        return this.f1123a.i();
    }

    public b8 i() {
        return this.f1123a.j();
    }

    public s8 j() {
        return this.f1123a.k();
    }

    public boolean k() {
        return this.f1123a.l();
    }

    public k9 l() {
        return this.f1123a.m();
    }

    public void a(Context context) {
        this.f1123a.a(context);
    }

    public void a(String str, String str2) {
        this.f1123a.a(str, str2);
    }
}
