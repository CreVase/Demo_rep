package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class r2 {

    /* renamed from: a, reason: collision with root package name */
    public static final r2 f1101a = new r2();

    /* renamed from: b, reason: collision with root package name */
    public static String f1102b = "";
    public static int[] c;

    public final String a() {
        return f1102b;
    }

    public final int[] b() {
        return c;
    }
}
