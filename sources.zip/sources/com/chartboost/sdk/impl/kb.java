package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public class kb {

    /* renamed from: a, reason: collision with root package name */
    public final yb f955a;

    /* renamed from: b, reason: collision with root package name */
    public final sb f956b;

    public kb() {
        yb ybVar = new yb();
        this.f955a = ybVar;
        this.f956b = new sb(ybVar);
    }

    public ab a() {
        return this.f956b;
    }

    public ab b() {
        return this.f955a;
    }
}
