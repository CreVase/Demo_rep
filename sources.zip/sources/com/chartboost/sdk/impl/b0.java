package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;

/* loaded from: classes.dex */
public interface b0 {
    void a(String str);

    void a(String str, int i);

    void a(String str, String str2, CBError.CBClickError cBClickError);

    void b(String str);

    void b(String str, CBError.CBImpressionError cBImpressionError);

    void d(String str);

    void e(String str);

    void f(String str);
}
