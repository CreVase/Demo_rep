package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface f1 {
    void e();
}
