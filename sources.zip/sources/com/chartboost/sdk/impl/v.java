package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface v {
    void a(s0 s0Var);
}
