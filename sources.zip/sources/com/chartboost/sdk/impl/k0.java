package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface k0 extends q8 {
    void a();

    void a(y9 y9Var);

    float c();

    void d();

    boolean f();

    void pause();

    void play();

    void stop();
}
