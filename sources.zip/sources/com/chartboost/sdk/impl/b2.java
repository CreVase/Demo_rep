package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class b2 {

    /* renamed from: a, reason: collision with root package name */
    public static final String f717a = "a2";
}
