package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class t2 extends RuntimeException {
    public t2() {
        super("Chartboost SDK is not initialized, call Chartboost.initWithAppId first");
    }
}
