package com.chartboost.sdk.impl;

import defpackage.x31;

/* loaded from: classes.dex */
public interface i {
    void a(d6 d6Var, x31 x31Var);
}
