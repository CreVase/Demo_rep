package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum r5 {
    INTERSTITIAL(0),
    INTERSTITIAL_VIDEO(1),
    INTERSTITIAL_REWARD_VIDEO(2),
    BANNER(3),
    NONE(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f1108a;

    r5(int i) {
        this.f1108a = i;
    }
}
