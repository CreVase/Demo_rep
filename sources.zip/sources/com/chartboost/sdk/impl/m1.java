package com.chartboost.sdk.impl;

import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public interface m1 {

    /* renamed from: a, reason: collision with root package name */
    public static final int f982a = (int) TimeUnit.DAYS.toSeconds(7);

    /* renamed from: b, reason: collision with root package name */
    public static final long f983b = TimeUnit.SECONDS.toMillis(15);
}
