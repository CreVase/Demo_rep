package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum t4 {
    VIDEO_CONTROLS,
    CLOSE_AD,
    NOT_VISIBLE,
    OTHER
}
