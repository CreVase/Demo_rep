package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class s1 {

    /* renamed from: a, reason: collision with root package name */
    public static final String f1121a = "q1";
}
