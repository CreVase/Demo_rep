package com.chartboost.sdk.impl;

import android.content.Context;
import com.chartboost.sdk.internal.Model.CBError;

/* loaded from: classes.dex */
public interface h5 {
    void a(Context context, String str, Boolean bool);

    void a(String str, CBError.CBClickError cBClickError);

    void a(boolean z);

    boolean a(Context context, Boolean bool, s5 s5Var);

    void b(String str, Float f, Float f2);

    void c();
}
