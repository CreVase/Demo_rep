package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum g7 {
    PORTRAIT,
    LANDSCAPE,
    PORTRAIT_REVERSE,
    LANDSCAPE_REVERSE,
    PORTRAIT_LEFT,
    PORTRAIT_RIGHT,
    LANDSCAPE_LEFT,
    LANDSCAPE_RIGHT
}
