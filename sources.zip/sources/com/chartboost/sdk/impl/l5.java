package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class l5 {

    /* renamed from: a, reason: collision with root package name */
    public final f2 f959a;

    /* renamed from: b, reason: collision with root package name */
    public final v2 f960b;
    public final b3 c;
    public final r5 d;
    public final v6 e;
    public final s0 f;
    public final u3 g;
    public final g2 h;
    public final r i;
    public final q j;
    public final String k;
    public final q5 l;
    public final c0 m;

    public l5(f2 f2Var, v2 v2Var, b3 b3Var, r5 r5Var, v6 v6Var, s0 s0Var, u3 u3Var, g2 g2Var, r rVar, q qVar, String str, q5 q5Var, c0 c0Var) {
        this.f959a = f2Var;
        this.f960b = v2Var;
        this.c = b3Var;
        this.d = r5Var;
        this.e = v6Var;
        this.f = s0Var;
        this.g = u3Var;
        this.h = g2Var;
        this.i = rVar;
        this.j = qVar;
        this.k = str;
        this.l = q5Var;
        this.m = c0Var;
    }

    public final q a() {
        return this.j;
    }

    public final r b() {
        return this.i;
    }

    public final c0 c() {
        return this.m;
    }

    public final s0 d() {
        return this.f;
    }

    public final v2 e() {
        return this.f960b;
    }

    public final b3 f() {
        return this.c;
    }

    public final u3 g() {
        return this.g;
    }

    public final q5 h() {
        return this.l;
    }

    public final String i() {
        return this.k;
    }

    public final r5 j() {
        return this.d;
    }

    public final v6 k() {
        return this.e;
    }

    public final f2 l() {
        return this.f959a;
    }

    public final g2 m() {
        return this.h;
    }
}
