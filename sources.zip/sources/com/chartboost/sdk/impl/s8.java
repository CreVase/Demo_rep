package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface s8 {
    o0 a();

    u8 b();

    o2 c();
}
