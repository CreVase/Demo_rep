package com.chartboost.sdk.impl;

import java.util.Date;

/* loaded from: classes.dex */
public class gc {
    public static long b() {
        return System.nanoTime();
    }

    public Date a() {
        return new Date();
    }
}
