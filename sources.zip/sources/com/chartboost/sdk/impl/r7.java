package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface r7 {
    p7 a();
}
