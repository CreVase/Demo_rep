package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface d1 {
    void a(s0 s0Var, String str, z0 z0Var, v vVar);
}
