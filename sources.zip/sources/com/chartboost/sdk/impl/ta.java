package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class ta {

    /* renamed from: a, reason: collision with root package name */
    public static final String f1161a = "sa";
}
