package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface o5 {
    void a();

    void a(s5 s5Var);

    void e(boolean z);
}
