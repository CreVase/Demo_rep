package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface k5 {
    void a(String str, Float f, Float f2);

    void d();
}
