package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum i3 {
    DEFINED_BY_JAVASCRIPT("definedByJavaScript"),
    HTML_DISPLAY("htmlDisplay"),
    NATIVE_DISPLAY("nativeDisplay"),
    VIDEO("video"),
    AUDIO("audio");


    /* renamed from: a, reason: collision with root package name */
    public final String f871a;

    i3(String str) {
        this.f871a = str;
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.f871a;
    }
}
