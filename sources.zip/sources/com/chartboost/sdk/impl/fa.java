package com.chartboost.sdk.impl;

import com.chartboost.sdk.impl.ea;

/* loaded from: classes.dex */
public final class fa {

    /* renamed from: a, reason: collision with root package name */
    public static final String f824a = ea.b.c.b();
}
