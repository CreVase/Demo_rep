package com.chartboost.sdk.impl;

import defpackage.bu0;
import defpackage.ot0;
import defpackage.y01;

/* loaded from: classes.dex */
public final class m4 {
    public static final int a(ot0 ot0Var) {
        bu0 bu0Var = (bu0) ot0Var;
        bu0Var.C();
        y01 y01Var = bu0Var.K;
        if (y01Var != null) {
            return y01Var.r;
        }
        return 1;
    }

    public static final int b(ot0 ot0Var) {
        bu0 bu0Var = (bu0) ot0Var;
        bu0Var.C();
        y01 y01Var = bu0Var.K;
        if (y01Var != null) {
            return y01Var.q;
        }
        return 1;
    }
}
