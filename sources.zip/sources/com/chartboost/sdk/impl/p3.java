package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum p3 {
    CTV("ctv"),
    MOBILE("mobile"),
    OTHER("other");


    /* renamed from: a, reason: collision with root package name */
    public final String f1066a;

    p3(String str) {
        this.f1066a = str;
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.f1066a;
    }
}
