package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum l7 {
    MINIMIZED("minimized"),
    COLLAPSED("collapsed"),
    NORMAL("normal"),
    EXPANDED("expanded"),
    FULLSCREEN("fullscreen");


    /* renamed from: a, reason: collision with root package name */
    public final String f964a;

    l7(String str) {
        this.f964a = str;
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.f964a;
    }
}
