package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface h8 {
    j8 build();
}
