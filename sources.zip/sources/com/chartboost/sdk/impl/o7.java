package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum o7 {
    IMMEDIATE(0),
    HIGH(1),
    NORMAL(2),
    LOW(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f1045a;

    o7(int i) {
        this.f1045a = i;
    }

    public final int b() {
        return this.f1045a;
    }
}
