package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class ma {

    /* renamed from: a, reason: collision with root package name */
    public static final String f999a = "la";
}
