package com.chartboost.sdk.impl;

import java.util.List;

/* loaded from: classes.dex */
public interface v6 {
    void a();

    void a(float f);

    void a(float f, float f2);

    void a(h6 h6Var, i2 i2Var, List<x9> list);

    void a(l7 l7Var);

    void a(x7 x7Var);

    void a(boolean z);

    void b();

    void c();

    void d();

    void e();

    void f();
}
