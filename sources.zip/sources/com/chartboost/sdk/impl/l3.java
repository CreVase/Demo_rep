package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public interface l3 {
    void a();

    void a(String str);

    void b();

    void c();

    void d();
}
