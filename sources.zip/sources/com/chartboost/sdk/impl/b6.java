package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum b6 {
    CLICK("click"),
    INVITATION_ACCEPTED("invitationAccept");


    /* renamed from: a, reason: collision with root package name */
    public String f727a;

    b6(String str) {
        this.f727a = str;
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.f727a;
    }
}
