package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class a7 {

    /* renamed from: a, reason: collision with root package name */
    public static final String f703a = "z6";
}
