package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;
import com.chartboost.sdk.view.CBImpressionActivity;

/* loaded from: classes.dex */
public interface d8 {
    void a();

    void a(a0 a0Var);

    void a(a aVar, CBImpressionActivity cBImpressionActivity);

    void a(ra raVar);

    void a(CBError.CBImpressionError cBImpressionError);

    void b();

    t8 c();

    void d();

    boolean e();

    void f();

    void g();

    void h();
}
