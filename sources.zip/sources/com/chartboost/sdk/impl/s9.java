package com.chartboost.sdk.impl;

import defpackage.v31;

/* loaded from: classes.dex */
public interface s9 {
    void a(long j, v31 v31Var);

    void a(v31 v31Var);
}
