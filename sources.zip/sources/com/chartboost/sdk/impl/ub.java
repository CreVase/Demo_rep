package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum ub {
    PARENT_VIEW,
    OBSTRUCTION_VIEW,
    UNDERLYING_VIEW
}
