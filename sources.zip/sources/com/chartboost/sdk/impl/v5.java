package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class v5 {

    /* renamed from: a, reason: collision with root package name */
    public static final String f1234a = "d5";
}
