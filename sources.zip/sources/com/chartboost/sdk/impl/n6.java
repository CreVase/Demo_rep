package com.chartboost.sdk.impl;

import com.chartboost.sdk.impl.c2;

/* loaded from: classes.dex */
public class n6 {

    /* renamed from: a, reason: collision with root package name */
    public final String f1010a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1011b;
    public final j8 c;
    public final o7 d;
    public final c2.a e;

    public n6(String str, String str2, j8 j8Var, o7 o7Var, c2.a aVar) {
        this.f1010a = str;
        this.f1011b = str2;
        this.c = j8Var;
        this.d = o7Var;
        this.e = aVar;
    }
}
