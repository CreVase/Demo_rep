package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum m7 {
    NONE(0),
    IDLE(1),
    PLAYING(2),
    PAUSED(3);


    /* renamed from: a, reason: collision with root package name */
    public final int f998a;

    m7(int i) {
        this.f998a = i;
    }
}
