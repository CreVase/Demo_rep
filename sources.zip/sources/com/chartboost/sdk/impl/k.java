package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public class k {

    /* renamed from: a, reason: collision with root package name */
    public final q f945a;

    /* renamed from: b, reason: collision with root package name */
    public final Integer f946b;
    public final Integer c;
    public final String d;
    public final int e;

    public k(q qVar, Integer num, Integer num2, String str, int i) {
        this.f945a = qVar;
        this.f946b = num;
        this.c = num2;
        this.d = str;
        this.e = i;
    }
}
