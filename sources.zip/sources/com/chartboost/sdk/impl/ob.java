package com.chartboost.sdk.impl;

import android.webkit.WebView;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class ob extends WeakReference<WebView> {
    public ob(WebView webView) {
        super(webView);
    }
}
