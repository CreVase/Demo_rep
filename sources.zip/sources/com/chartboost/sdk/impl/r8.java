package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class r8 {
    public static String a(String str, String str2) {
        return wb.b(str, str2);
    }
}
