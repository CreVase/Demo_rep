package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum i7 {
    NOT_DETECTED,
    UNKNOWN
}
