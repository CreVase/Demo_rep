package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class c9 {
    public static final long a() {
        return System.currentTimeMillis();
    }
}
