package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public final class h0 {

    /* renamed from: a, reason: collision with root package name */
    public static final String f848a = "g0";

    public static final String b(int i) {
        return i != 1 ? i != 2 ? i != 3 ? i != 4 ? "UNKNOWN" : "STATE_ENDED" : "STATE_READY" : "STATE_BUFFERING" : "STATE_IDLE";
    }
}
