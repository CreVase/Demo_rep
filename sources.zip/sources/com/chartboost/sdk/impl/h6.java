package com.chartboost.sdk.impl;

/* loaded from: classes.dex */
public enum h6 {
    UNKNOWN(0),
    HTML(1),
    VIDEO(2),
    AUDIO(3),
    NATIVE(4);


    /* renamed from: a, reason: collision with root package name */
    public final int f856a;

    h6(int i) {
        this.f856a = i;
    }

    public final int b() {
        return this.f856a;
    }
}
