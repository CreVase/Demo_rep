package com.chartboost.sdk.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;

/* loaded from: classes.dex */
public interface q0 {
    h1 a();

    s9 b();

    z8 c();

    Handler d();

    p0 e();

    SharedPreferences f();

    k8 g();

    Context getContext();
}
