package com.chartboost.sdk.events;

/* loaded from: classes.dex */
public interface CBError {
    Exception getException();
}
