package com.chartboost.sdk.events;

import com.chartboost.sdk.ads.Ad;

/* loaded from: classes.dex */
public interface AdEvent {
    Ad getAd();

    String getAdID();
}
