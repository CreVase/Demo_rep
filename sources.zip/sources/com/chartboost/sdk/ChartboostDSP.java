package com.chartboost.sdk;

/* loaded from: classes.dex */
public final class ChartboostDSP {
    public static final ChartboostDSP INSTANCE = new ChartboostDSP();

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f690a = false;

    public static final boolean setDSPHeader(String str, int[] iArr) {
        return false;
    }

    public final boolean isDSP() {
        return f690a;
    }
}
