package com.chartboost.sdk.callbacks;

import com.chartboost.sdk.events.StartError;

/* loaded from: classes.dex */
public interface StartCallback {
    void onStartCompleted(StartError startError);
}
