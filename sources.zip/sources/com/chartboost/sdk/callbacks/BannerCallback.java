package com.chartboost.sdk.callbacks;

/* loaded from: classes.dex */
public interface BannerCallback extends AdCallback {
}
