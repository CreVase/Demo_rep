package com.chartboost.sdk.callbacks;

/* loaded from: classes.dex */
public interface InterstitialCallback extends DismissibleAdCallback {
}
